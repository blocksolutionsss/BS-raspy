# config.py

SOCKETIO_HOST = 'http://192.168.43.172:3000'
DEVICE = "device10"